<!DOCTYPE html>
<html lang="zxx">
   <head>
      <title>Track | Linka Express Official Website</title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="LINKA EXPRESS, deliver online, ship your goods , LINKA EXPRESS" />
      <script type="application/x-javascript">
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
         function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!--//meta tags ends here-->
      <!--booststrap-->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
      <!--//booststrap end-->
      <!--stylesheets-->
      <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//stylesheets--> 
      <!-- font-awesome icons -->
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <!-- partner js-->
      <link href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
   </head>
   <body>
      <!--navbar-->
      <!--headder-->
      <div class="header-w3layouts">
         <div class="container">
            <div class="header-bar">
            <nav class="navbar navbar-default">
                  <div class="navbar-header navbar-left">
                     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     </button>
                     <h1><a class="navbar-brand" href="index.php"><img src="images/logo.jpg">
                        </a>
                     </h1>
                  </div>
                  <!-- Collect the nav links, forms, and other content for toggling -->
                  <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                     <nav>
                        <ul class="nav navbar-nav">
                           <li class="active"><a href="index.php"><span class="fa fa-home banner-nav" aria-hidden="true"></span>Home</a></li>
                           <li><a href="about.php"><span class="fa fa-info-circle banner-nav" aria-hidden="true"></span>About</a></li>
                           <li><a href="services.php"><span class="fa fa-cogs banner-nav" aria-hidden="true"></span>Services</a></li>
                         <!--  <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-file banner-nav" aria-hidden="true"></span>Pages<span class="caret"></span>
                              </a>
                              <ul class="dropdown-menu" role="menu">
                                 <li>
                                    <a href="icons.html">Web Icons</a>
                                 </li>
                                 <li>
                                    <a href="codes.html">Short Codes</a>
                                 </li>
                              </ul>
                           </li>-->
                           <li><a href="track.php"><span class="fa fa-picture-o banner-nav" aria-hidden="true"></span>Track Package</a></li>
                           <li><a href="contact.php"><span class="fa fa-envelope-o banner-nav" aria-hidden="true"></span>Contact</a></li>
                           <li id="google_translate_element"></li>
                           
                        </ul>
                     </nav>            </div>
            <div class="clearfix"> </div>
         </div>
      </div>
      <!--//headder-->
      <!--//navbar-->
      <!-- banner -->
      <div class="inner_page_about">
      </div>
      <!--//banner -->
     
      <!--newsletter -->
      <div class="buttom-w3">
         <div class="container">
          
         </div>
         <div class="news-info text-center">
             <span> </span> 
            <h4>Track your Package</h4>
            <div class="post">
               <form action="track_result.php" method="post">
                  <div class="letter">
                     <input class="email" type="text" name="track_code" placeholder="Enter your tracking ID..." required="">
                  </div>
                  <div class="newsletter">
                     <input type="submit" name="track_now" value="Track">
                  </div>
               </form>
            </div>
            
         </div>
      </div>
      <!--//newsletter -->
      <!--footer -->
      <footer>
         <div class="container">
            <div class="col-md-6 col-sm-7 header-side">
               <div class="header-side">
                  <div class="buttom-social-grids">
                     <ul>
                        <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="#"><span class="fa fa-rss"></span></a></li>
                        <li><a href="#"><span class="fa fa-vk"></span></a></li>
                     </ul>
                  </div>
               </div>
               <p>©2020 Linka Express WorldWide Delivery. All Rights Reserved. </p>
            </div>
            <div class="col-md-6 col-sm-5 header-right">
               <h2><a href="index.php">Linka Express</a></h2>
            </div>
         </div>
      </footer>
      <!--//footer -->
      <!--js working-->
      <script src='js/jquery-2.2.3.min.js'></script>
      <!-- //js  working-->
      <!-- start-smoth-scrolling -->
      <script src="js/move-top.js"></script>
      <script src="js/easing.js"></script>
      <script>
         jQuery(document).ready(function ($) {
         	$(".scroll").click(function (event) {
         		event.preventDefault();
         		$('html,body').animate({
         			scrollTop: $(this.hash).offset().top
         		}, 1000);
         	});
         });
      </script>
      <!-- start-smoth-scrolling -->
      <!-- for-bottom-to-top smooth scrolling -->
      <script>
         $(document).ready(function () {
         	/*
         		var defaults = {
         		containerID: 'toTop', // fading element id
         		containerHoverID: 'toTopHover', // fading element hover id
         		scrollSpeed: 1200,
         		easingType: 'linear' 
         		};
         	*/
         	$().UItoTop({
         		easingType: 'easeOutQuart'
         	});
         });
      </script>
      <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
      <!-- //for-bottom-to-top smooth scrolling -->
      <!-- bootstrap-->
      <script src="js/bootstrap.js"></script>
      <!--// bootstrap-->
      
      <!-- Google translate -->
      <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
   </body>
</html>