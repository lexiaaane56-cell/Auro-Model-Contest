<!DOCTYPE html>
<html lang="zxx">
   <head>
      <title>Linka Express Official Website</title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">

      <meta name="keywords" content="Linka Express, deliver online, ship your goods ,Global Delivery" />
      <script type="application/x-javascript">
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
         function hideURLbar(){ window.scrollTo(0,1); }
      </script>
          <!-- Favicon -->
<link rel="shortcut icon" href="favicon.ico" />
      <!--//meta tags ends here-->
      <!--booststrap-->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
      <!--//booststrap end-->
      <!--stylesheets-->
      <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//stylesheets--> 
      <!-- font-awesome icons -->
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <!-- //font-awesome icons -->
      <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
      <!-- partner js-->
      <link href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
   </head>
   <body>
      <div class="header-w3layouts">
         <div class="container">
            <div class="header-bar">
               <nav class="navbar navbar-default">
                  <div class="navbar-header navbar-left">
                     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     </button>
                     <h1><a class="navbar-brand" href="index.php"><img src="images/logo.jpg">
                        </a>
                     </h1>
                  </div>
                  <!-- Collect the nav links, forms, and other content for toggling -->
                  <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                     <nav>
                        <ul class="nav navbar-nav">
                           <li class="active"><a href="index.php"><span class="fa fa-home banner-nav" aria-hidden="true"></span>Home</a></li>
                           <li><a href="about.php"><span class="fa fa-info-circle banner-nav" aria-hidden="true"></span>About</a></li>
                           <li><a href="services.php"><span class="fa fa-cogs banner-nav" aria-hidden="true"></span>Services</a></li>
                         <!--  <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-file banner-nav" aria-hidden="true"></span>Pages<span class="caret"></span>
                              </a>
                              <ul class="dropdown-menu" role="menu">
                                 <li>
                                    <a href="icons.html">Web Icons</a>
                                 </li>
                                 <li>
                                    <a href="codes.html">Short Codes</a>
                                 </li>
                              </ul>
                           </li>-->
                           <li><a href="track.php"><span class="fa fa-picture-o banner-nav" aria-hidden="true"></span>Track Package</a></li>
                           <li><a href="contact.php"><span class="fa fa-envelope-o banner-nav" aria-hidden="true"></span>Contact</a></li>
                           <li id="google_translate_element"></li>
                           
                        </ul>
                     </nav>                  </div>
               </nav>
            </div>
            <div class="clearfix"> </div>
         </div>
      </div>
      <!-- Slideshow 4 -->
      <div class="slider">
         <div class="callbacks_container">
            <ul class="rslides" id="slider4">
               <li>
                  <div class="slider-img w3-oneimg">
                     <div class="container">
                        <div class="slider-info">
                           <h6></h6>
                           <h4>Linka Express International Delivery</h4>
                           <p>Send your goods  WorldWide
                           </p>
                        </div>
                     </div>
                  </div>
               </li>
               <li>
                  <div class="slider-img w3-twoimg">
                     <div class="container">
                        <div class="slider-info">
                           <h6>Worldwide</h6>
                           <h4>Biggest  Network</h4>
                           <p>Welcome to Linka Express WorldWide Delivery
                           </p>
                        </div>
                     </div>
                  </div>
               </li>
               <li>
                  <div class="slider-img w3-threeimg">
                     <div class="container">
                        <div class="slider-info">
                           <h6>Supplying</h6>
                           <h4>Secured Shipping</h4>
                           <p>Fast Secure and Reliable
                           </p>
                        </div>
                     </div>
                  </div>
               </li>
            </ul>
         </div>
         <div class="clearfix"> </div>
         <!-- This is here just to demonstrate the callbacks -->
         <!-- <ul class="events">
            <li>Example 4 callback events</li>
            </ul>-->
      </div>
      <!--//banner-->

       <!--newsletter -->
       <div class="buttom-w3">
         <div class="container">
           
         </div>
         <div class="news-info text-center">
            <h4>Track your Package</h4>
            <div class="post">
              <!--  <form action="#" method="post">
                 <div class="letter">
                     <input class="email" type="text" placeholder="Enter your tracking ID..." required="">
                  </div> -->
                  <div class="newsletter">
             <a href="track">        <input type="submit" value="Track"> </a>
                  </div>
              <!-- </form> -->
            </div>
            
         </div>
      </div>
      <!--//newsletter -->
      <div class="about" id="about">
         <div class="container">
            <div class="about-banner-grids ">
               <div class="col-md-4 left-of-about">
                  <h3>What We Do</h3>
                  <div class=" about-matter-left">
                     <p>We provide tailored Tracking Services  
                     </p>
                     <p> As a market leader in freight forwarding, supply chain solutions that can optimize the effectiveness 
                        of your product promotion, and reduce the cost of your packaging and distribution.</p>
                  </div>
                  <div class="clearfix"></div>
               </div>
               <div class="col-md-4 about-pic">
               </div>
               <div class="col-md-4 right-of-about">
                  <div class="about-airway colo">
                     <p>We provide the latest tracking Technology that helps you track your goods and packages all the way with update on every location,
                         so you can never be out of reach. You are updated in real time all the time.
                     </p>
                  </div>
               </div>
               <div class="clearfix"></div>
            </div>
            <div class="col-md-6 about-right-info">
            </div>
            <div class=" col-md-6 about-info-air">
               <div class="air-list">
                  <h4>logistic Solutions</h4>
                  <p>We have a wide experience in overland industry specific logistic solutions like pharmaceutical logistics, 
                     retail and automotive logistics by train or road. We provide professional 
                     Parcel solution for our clients.
                  </p>
               </div>
               <div class="air-list">
                  <h4>Global and local expertise</h4>
                  <p>Linka Express Trade Managers each have an in-depth understanding of individual overseas markets and the dynamics of specific trades.
                      This expertise enables them to provide you with market-specific.
                       
                  </p>
               </div>
               <div class="air-list">
                  <h4>Vast Streamlined Services.</h4>
                  <p>A far reaching, refined, 
                     network to enable smooth, uninterrupted freight transport 
                     and freight services across the globe. 
                  </p>
               </div>
            </div>
         </div>
      </div>
      <!--// About-->
      <!-- services-->
      <div class="services" id="services">
         <h3 class="title clr">Services</h3>
         <div class="banner-bottom-girds">
            <div class="col-md-4 col-sm-6 col-xs-6 its-banner-grid gird-ser-clr2">
                
                
               <div class="white-shadow">
                  <div class="white-left">
                     <span class="fa fa-truck banner-icon" aria-hidden="true"></span>
                  </div>
                  <div class="white-right">
                     <h4>Best Logistic</h4>
                     <p> if you’re looking for a shipping solution that’s faster than a postal courier but not as expensive as an express courier, consider using Linka Express, as we on premium service focus our delivery on certain regions or areas around the world. Pay the lowest available price for the length of your route. See your price come down as other businesses join with nearby deliveries.</p>
                  </div>
                  <div class="clearfix"> </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6 its-banner-grid gird-ser-clr">
               <div class="white-shadow">
                  <div class="white-left">
                     <span class="fa fa-clock-o banner-icon" aria-hidden="true"></span>
                  </div>
                  <div class="white-right">
                     <h4>Fast Delivery</h4>
                     <p>Specialized, integrated, value-adding solutions to enable you to focus on your core business.  uninterrupted freight transport 
                        and freight services across the globe.</p>
                  </div>
                  <div class="clearfix"> </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6 its-banner-grid gird-ser-clr2">
               <div class="white-shadow">
                  <div class=" white-left">
                     <span class="fa fa-lock banner-icon" aria-hidden="true"></span>
                  </div>
                  <div class=" white-right">
                     <h4>Secured Service</h4>
                     <p>we take pride in serving our customers with the utmost honesty and integrity anyday any time.</p>
                  </div>
                  <div class="clearfix"> </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6 its-banner-grid colo">
               <div class="white-shadow">
                  <div class=" white-left">
                     <span class="fa fa-archive banner-icon" aria-hidden="true"></span>
                  </div>
                  
                  
                  <div <i class="fa fa-phone" aria-hidden="true"></i>
                     <h4>Quick Link</h4>
                     <p> .</p> 
                     <p>click on whatsapp for a quick booking and enquiries</p></br>
                     <i class="fa fa-whatsapp" aria-hidden="true"></i>
                  <h4><a href="https://wa.link/i3d4vl">Whatsapp</a></h4>
                  </br>
                 
                 <i class="fa fa-phone" aria-hidden="true"></i>
                  </div>
                  <h4>+17084009857</h4> </br>
                 
                 <p><a href="mailto:Admin@linkaexpress.com">Admin@linkaexpress.com</a> 
                     <span><a href="mailto:services@linkaexpress.com"></a></spa>
                  </p>
                 
                  </div>
                  
                  
                  
                  <div class="clearfix"> </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6 its-banner-grid gird-ser-clr2">
               <div class="white-shadow">
                  <div class="white-right">
                     <div class="white-left">
                        <span class="fa fa-fighter-jet banner-icon" aria-hidden="true"></span>
                     </div>
                     <h4>Fly Anywhere</h4>
                     <p>We have built tracker into every one of our delivery vehicles. With its months-long battery life and global cell connectivity, a Portobel tracker transmits detailed temperature and location data throughout your shipments’ entire journey in real timely.</p>
                  </div>
                  <div class="clearfix"> </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-6 col-xs-6 its-banner-grid colo">
               <div class="white-shadow">
                  <div class="white-right">
                     <div class=" white-left">
                        <span class="fa fa-home banner-icon" aria-hidden="true"></span>
                     </div>
                     <h4>Advantage </h4>
                     <p> When you work with Linka Express, you can be sure that your perishable goods are handled correctly and delivered fresh. Known for dedication and professionalism, and keeping to all standards, please Schedule a pick up with us today.</p>
                  </div>
                  <div class="clearfix"> </div>
               </div>
            </div>
            <div class="clearfix"> </div>
         </div>
      </div>
      <!--// services-->
     <!-- counter-->
     <div class="static" id="rate">
      <div class="container">
         <div class="stats-info agileits w3layouts">
            <div class="col-md-3 col-sm-3 col-xs-3 agileits w3layouts stats-grid stats-grid-1">
               <div class="ser-icone"> <span class="fa fa-plane font" aria-hidden="true"></span>
               </div>
               <div class=" agileits-w3layouts counter">999567</div>
               <div class="stat-info-w3ls">
                  <h4 class="agileits w3layouts">Packed Moved</h4>
               </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-3 agileits w3layouts stats-grid stats-grid-2">
               <div class="ser-icone"> <span class="fa fa-user font" aria-hidden="true"></span>
               </div>
               <div class=" agileits-w3layouts counter">1540</div>
               <div class="stat-info-w3ls">
                  <h4 class="agileits w3layouts ">Clients</h4>
               </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-3 stats-grid agileits w3layouts stats-grid-3">
               <div class="ser-icone"> <span class="fa fa-cubes font" aria-hidden="true"></span>
               </div>
               <div class=" agileits-w3layouts counter">145678</div>
               <div class="stat-info-w3ls">
                  <h4 class="agileits w3layouts "> Delivery</h4>
               </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-3 stats-grid agileits w3layouts stats-grid-4">
               <div class="ser-icone"> <span class="fa fa-truck font" aria-hidden="true"></span>
               </div>
               <div class=" agileits-w3layouts counter">100%</div>
               <div class="stat-info-w3ls">
                  <h4 class="agileits w3layouts">Logistics</h4>
               </div>
            </div>
            <div class="clearfix"></div>
         </div>
      </div>
   </div>
   <!-- //counter-->
      <!--testimonials-->
     
      
      
      <div class="testimonials colo" id="testimonials">
         <div class="container">
            <h3 class="title clr">testimonials</h3>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
               <!-- Indicators --> 
               <ol class="carousel-indicators">
                  <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="2"></li>
               </ol>
               <!-- Wrapper for slides -->
               <div class="carousel-inner">
                  <div class="item active">
                     <div class="thumbnail adjust1">
                        <div class="col-md-5 col-sm-5 right-says">
                           <img class="img-responsive" src="images/t1.jpg" alt=""> 
                        </div>
                        <div class="col-md-7 col-sm-7 client-img">
                           <div class="caption">
                              <p><span class="fa fa-quote-left client-quote" aria-hidden="true"></span>The most valuable resource they have is their employees. 
                                 Their relentless pursuit of perfection is what has enabled Linka Express
                                  to deliver the premium level of service which it is known for.<span class="fa fa-quote-right client-quote" aria-hidden="true"></span>
                              </p>
                           </div>
                           <blockquote class="adjust2">
                              <h6>Lois Wlly</h6>
                           </blockquote>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="thumbnail adjust1">
                        <div class="col-md-5 col-sm-5 right-says">
                           <img class="img-responsive" src="images/t2.jpg" alt=""> 
                        </div>
                        <div class="col-md-7 col-sm-7 client-img">
                           <div class="caption">
                              <p><span class="fa fa-quote-left client-quote" aria-hidden="true"></span>I have always received good service from Linka Express. Timing and quality have always met my expectations and everything is communicated in a professional and timely manner. .<span class="fa fa-quote-right client-quote" aria-hidden="true"></span>
                              </p>
                           </div>
                           <blockquote class="adjust2">
                              <h6>Max Willson</h6>
                           </blockquote>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="thumbnail adjust1">
                        <div class="col-md-5 col-sm-5 right-says"> 
                           <img class=" img-responsive" src="images/t3.jpg" alt=""> 
                        </div>
                        <div class="col-md-7 col-sm-7 client-img">
                           <div class="caption">
                              <p><span class="fa fa-quote-left client-quote" aria-hidden="true"></span>Linka Express experienced team can identify the perfect locations, secure site permissions, manage schedules, coordinate cast and crew, and provide technical support. You should use linka Express.<span class="fa fa-quote-right client-quote" aria-hidden="true"></span>
                              </p>
                           </div>
                           <blockquote class="adjust2">
                              <h6>Kenny East</h6>
                           </blockquote>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- Controls --> 
               <!--<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"> 
                  <span class="fa fa-chevron-left"></span> </a>
                  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"> 
                  <span class="fa fa-chevron-right"></span> </a> 
                  </div> </div> --> 
               <!--// testimonials-->
            </div>
         </div>
      </div>
      
      <!--partners-->
      <div class="parnters" id="parnters">
         <div class="container">
            <h3 class="title clr">Our Partners</h3>
            <div class="flexslider-info">
               <section class="slider side-side">
                  <div class="flexslider">
                     <ul class="slides">
                        <li>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo1.jpg" alt="logo1" class="img-responsive">
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo2.jpg" alt="logo1" class="img-responsive">
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo3.jpg" alt="logo1" class="img-responsive">
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo1.jpg" alt="logo1" class="img-responsive">
                           </div>
                        </li>
                        <li>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo5.jpg" alt="logo1" class="img-responsive">
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo6.jpg" alt="logo1" class="img-responsive">
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo7.jpg" alt="logo1" class="img-responsive">
                           </div>
                           <div class="col-md-3 col-sm-3 col-xs-3 usr-img">
                              <img src="images/logo8.jpg" alt="logo1" class="img-responsive">
                           </div>
                        </li>
                     </ul>
                  </div>
                  <div class="clearfix"> </div>
               </section>
            </div>
            <div class="clearfix"> </div>
         </div>
      </div>
      <!--//partners -->
      <!--footer -->
      <footer>
         <div class="container">
            <div class="col-md-6 col-sm-7 header-side">
               <div class="header-side">
                  <div class="buttom-social-grids">
                     <ul>
                        <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="#"><span class="fa fa-rss"></span></a></li>
                        <li><a href="#"><span class="fa fa-vk"></span></a></li>
                     </ul>
                  </div>
               </div>
               <p>©2020 Linka Express WorldWide Delivery. All Rights Reserved. </p>
               

               
               
            </div>
            
            <div class="col-md-6 col-sm-5 header-right">
               <h2><a href="index.html">Linka Express</a></h2>
            </div>
         </div>
         
  
      </footer>
      <!--//footer -->
      <!--js working-->
      <script  src='js/jquery-2.2.3.min.js'></script>
      <!-- //js  working-->
      <!-- banner-->
      <script src="js/responsiveslides.min.js"></script>
      <script>
         // You can also use "$(window).load(function() {"
         $(function () {
           // Slideshow 4
         $("#slider4").responsiveSlides({
             auto: true,
             pager: false,
             nav: true,
             speed: 900,
             namespace: "callbacks",
             before: function () {
               $('.events').append("<li>before event fired.</li>");
             },
             after: function () {
               $('.events').append("<li>after event fired.</li>");
             }
           });
         
         });
      </script>
      <!--// banner-->
      <!--partner-->
      <script src="js/jquery.flexslider.js"></script>
      <!--Start-slider-script-->
      <script>
         $(window).load(function(){
         	$('.flexslider').flexslider({
         	animation: "slide",
         	start: function(slider){
         		$('body').removeClass('loading');
         	}
         	});
         });
      </script>
      <!--End-slider-script partner-->
      <!-- start-smoth-scrolling -->
      <script src="js/move-top.js"></script>
      <script src="js/easing.js"></script>
      <script>
         jQuery(document).ready(function ($) {
         	$(".scroll").click(function (event) {
         		event.preventDefault();
         		$('html,body').animate({
         			scrollTop: $(this.hash).offset().top
         		}, 1000);
         	});
         });
      </script>
      <!-- start-smoth-scrolling -->
      <!-- for-bottom-to-top smooth scrolling -->
      <script>
         $(document).ready(function () {
         	/*
         		var defaults = {
         		containerID: 'toTop', // fading element id
         		containerHoverID: 'toTopHover', // fading element hover id
         		scrollSpeed: 1200,
         		easingType: 'linear' 
         		};
         	*/
         	$().UItoTop({
         		easingType: 'easeOutQuart'
         	});
         });
      </script>
      <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
      <!-- //for-bottom-to-top smooth scrolling -->
      <!-- bootstrap-->
      <script src="js/bootstrap.js"></script>
      <!--// bootstrap-->
      
      
      <!-- Google translate -->
      <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
   </body>
</html>