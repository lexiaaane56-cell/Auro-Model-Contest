
<!DOCTYPE html>
<html lang="zxx">
   <head>
      <title>About Us | Linka Express Official Website</title>
      <!--meta tags -->
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="keywords" content="Linka Express, deliver online, ship your goods , linka Express" />
      <script type="application/x-javascript">
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
         function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!--//meta tags ends here-->
      <!--booststrap-->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
      <!--//booststrap end-->
      <!--stylesheets-->
      <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//stylesheets--> 
      <!-- font-awesome icons -->
      <link href="css/font-awesome.min.css" rel="stylesheet">
      <!-- partner js-->
      <link href="//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
   </head>
   <body>
      <!--navbar-->
      <!--headder-->
      <div class="header-w3layouts">
         <div class="container">
            <div class="header-bar">
            <nav class="navbar navbar-default">
                  <div class="navbar-header navbar-left">
                     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                     <span class="sr-only">Toggle navigation</span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     </button>
                     <h1><a class="navbar-brand" href="index.php"><img src="images/logo.jpg">
                        </a>
                     </h1>
                  </div>
                  <!-- Collect the nav links, forms, and other content for toggling -->
                  <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
                     <nav>
                        <ul class="nav navbar-nav">
                           <li class="active"><a href="index.php"><span class="fa fa-home banner-nav" aria-hidden="true"></span>Home</a></li>
                           <li><a href="about.php"><span class="fa fa-info-circle banner-nav" aria-hidden="true"></span>About</a></li>
                           <li><a href="services.php"><span class="fa fa-cogs banner-nav" aria-hidden="true"></span>Services</a></li>
                         <!--  <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="fa fa-file banner-nav" aria-hidden="true"></span>Pages<span class="caret"></span>
                              </a>
                              <ul class="dropdown-menu" role="menu">
                                 <li>
                                    <a href="icons.html">Web Icons</a>
                                 </li>
                                 <li>
                                    <a href="codes.html">Short Codes</a>
                                 </li>
                              </ul>
                           </li>-->
                           <li><a href="track.php"><span class="fa fa-picture-o banner-nav" aria-hidden="true"></span>Track Package</a></li>
                           <li><a href="contact.php"><span class="fa fa-envelope-o banner-nav" aria-hidden="true"></span>Contact</a></li>
                           <li id="google_translate_element"></li>
                           
                        </ul>
                     </nav>                  </div>
               </nav>
            </div>
            <div class="clearfix"> </div>
         </div>
      </div>
      <!--//headder-->
      <!--//navbar-->
      <!-- banner -->
      <div class="inner_page_about">
      </div>
      <!--//banner -->
      <!--About-->
      <div class="about" id="about">
         <div class="container">
            <h3 class="title">Why Us?</h3>
            <div class="about-inner-grids">
               <div class="col-md-5 col-sm-6 about-top-inner">
                  <div class="about-inner">
                     <ul>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p>Fast Delivery </p>
                        </li>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p>Secure and Reliable </p>
                        </li>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p>24 hours customer service </p>
                        </li>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p>Unique tracking order & maximum up time </p>
                        </li>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p>Tailored Tracking Services</p>
                        </li>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p> Wide experience in overland industry </p>
                        </li>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p>commitment & dedication </p>
                        </li>
                        <li>
                           <span class="fa fa-arrow-right dog-arrow" aria-hidden="true"></span>
                           <p>Global and Local expertise </p>
                        </li>
                     </ul>
                  </div>
               </div>
               <div class="col-md-7 col-sm-6 pope about-inner-img">
               </div>
               <div class="clearfix"> </div>
            </div>
         </div>
      </div>
      <!--//About-->
      <!-- counter-->
      <div class="static" id="rate">
         <div class="container">
            <div class="stats-info agileits w3layouts">
               <div class="col-md-3 col-sm-3 col-xs-3 agileits w3layouts stats-grid stats-grid-1">
                  <div class="ser-icone"> <span class="fa fa-plane font" aria-hidden="true"></span>
                  </div>
                  <div class=" agileits-w3layouts counter">999567</div>
                  <div class="stat-info-w3ls">
                     <h4 class="agileits w3layouts">Packed Moved</h4>
                  </div>
               </div>
               <div class="col-md-3 col-sm-3 col-xs-3 agileits w3layouts stats-grid stats-grid-2">
                  <div class="ser-icone"> <span class="fa fa-user font" aria-hidden="true"></span>
                  </div>
                  <div class=" agileits-w3layouts counter">1540</div>
                  <div class="stat-info-w3ls">
                     <h4 class="agileits w3layouts ">Clients</h4>
                  </div>
               </div>
               <div class="col-md-3 col-sm-3 col-xs-3 stats-grid agileits w3layouts stats-grid-3">
                  <div class="ser-icone"> <span class="fa fa-cubes font" aria-hidden="true"></span>
                  </div>
                  <div class=" agileits-w3layouts counter">145678</div>
                  <div class="stat-info-w3ls">
                     <h4 class="agileits w3layouts "> Delivery</h4>
                  </div>
               </div>
               <div class="col-md-3 col-sm-3 col-xs-3 stats-grid agileits w3layouts stats-grid-4">
                  <div class="ser-icone"> <span class="fa fa-truck font" aria-hidden="true"></span>
                  </div>
                  <div class=" agileits-w3layouts counter">100%</div>
                  <div class="stat-info-w3ls">
                     <h4 class="agileits w3layouts">Logistics</h4>
                  </div>
               </div>
               <div class="clearfix"></div>
            </div>
         </div>
      </div>
      <!-- //counter-->
      <!--testimonials-->
      <div class="testimonials colo" id="testimonials">
         <div class="container">
            <h3 class="title clr">testimonials</h3>
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
               <!-- Indicators --> 
               <ol class="carousel-indicators">
                  <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="2"></li>
               </ol>
               <!-- Wrapper for slides -->
               <div class="carousel-inner">
                  <div class="item active">
                     <div class="thumbnail adjust1">
                        <div class="col-md-5 col-sm-5 right-says">
                           <img class="img-responsive" src="images/t1.jpg" alt=""> 
                        </div>
                        <div class="col-md-7 col-sm-7 client-img">
                           <div class="caption">
                              <p><span class="fa fa-quote-left client-quote" aria-hidden="true"></span>The most valuable resource they have is their employees. 
                                 Their relentless pursuit of perfection is what has enabled WorldWide delivering
                                  to deliver the premium level of service which it is known for.<span class="fa fa-quote-right client-quote" aria-hidden="true"></span>
                              </p>
                           </div>
                           <blockquote class="adjust2">
                              <h6>Lois Wlly</h6>
                           </blockquote>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="thumbnail adjust1">
                        <div class="col-md-5 col-sm-5 right-says">
                           <img class="img-responsive" src="images/t2.jpg" alt=""> 
                        </div>
                        <div class="col-md-7 col-sm-7 client-img">
                           <div class="caption">
                              <p><span class="fa fa-quote-left client-quote" aria-hidden="true"></span>The most valuable resource they have is their employees. 
                                 Their relentless pursuit of perfection is what has enabled WorldWide delivering
                                  to deliver the premium level of service which it is known for.<span class="fa fa-quote-right client-quote" aria-hidden="true"></span>
                              </p>
                           </div>
                           <blockquote class="adjust2">
                              <h6>Max Willson</h6>
                           </blockquote>
                        </div>
                     </div>
                  </div>
                  <div class="item">
                     <div class="thumbnail adjust1">
                        <div class="col-md-5 col-sm-5 right-says"> 
                           <img class=" img-responsive" src="images/t3.jpg" alt=""> 
                        </div>
                        <div class="col-md-7 col-sm-7 client-img">
                           <div class="caption">
                              <p><span class="fa fa-quote-left client-quote" aria-hidden="true"></span>The most valuable resource they have is their employees. 
                                 Their relentless pursuit of perfection is what has enabled Linka Express
                                  to deliver the premium level of service which it is known for.<span class="fa fa-quote-right client-quote" aria-hidden="true"></span>
                              </p>
                           </div>
                           <blockquote class="adjust2">
                              <h6>Kenny East</h6>
                           </blockquote>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- Controls --> 
               <!--<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"> 
                  <span class="fa fa-chevron-left"></span> </a>
                  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"> 
                  <span class="fa fa-chevron-right"></span> </a> 
                  </div> </div> --> 
               <!--// testimonials-->
            </div>
         </div>
      </div>
      
      
       <!--newsletter -->
       <div class="buttom-w3">
         <div class="container">
           
         </div>
         <div class="news-info text-center">
            <h4>Track your Package</h4>
            <div class="post">
               <form action="#" method="post">
                  <div class="letter">
                     <input class="email" type="text" placeholder="Enter your tracking ID..." required="">
                  </div>
                  <div class="newsletter">
                     <input type="submit" value="Track">
                  </div>
               </form>
            </div>
            
         </div>
      </div>
      <!--//newsletter -->
      <!--footer -->
      <footer>
         <div class="container">
            <div class="col-md-6 col-sm-7 header-side">
               <div class="header-side">
                  <div class="buttom-social-grids">
                     <ul>
                        <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                        <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                        <li><a href="#"><span class="fa fa-rss"></span></a></li>
                        <li><a href="#"><span class="fa fa-vk"></span></a></li>
                     </ul>
                  </div>
               </div>
               <p>©2020 Linka Express WorldWide Delivery. All Rights Reserved. </p>
            </div>
            <div class="col-md-6 col-sm-5 header-right">
               <h2><a href="index.html">LINKA EXPRESS</a></h2>
            </div>
         </div>
      </footer>
      <!--//footer -->
      <!--js working-->
      <script  src='js/jquery-2.2.3.min.js'></script>
      <!-- //js  working-->
      <!-- OnScroll-Number-Increase-JavaScript -->
      <script src="js/jquery.waypoints.min.js"></script>
      <script src="js/jquery.countup.js"></script>
      <script>
         $('.counter').countUp();
      </script>
      <!-- //OnScroll-Number-Increase-JavaScript -->
      <!-- start-smoth-scrolling -->
      <script src="js/move-top.js"></script>
      <script src="js/easing.js"></script>
      <script>
         jQuery(document).ready(function ($) {
         	$(".scroll").click(function (event) {
         		event.preventDefault();
         		$('html,body').animate({
         			scrollTop: $(this.hash).offset().top
         		}, 1000);
         	});
         });
      </script>
      <!-- start-smoth-scrolling -->
      <!-- for-bottom-to-top smooth scrolling -->
      <script>
         $(document).ready(function () {
         	/*
         		var defaults = {
         		containerID: 'toTop', // fading element id
         		containerHoverID: 'toTopHover', // fading element hover id
         		scrollSpeed: 1200,
         		easingType: 'linear' 
         		};
         	*/
         	$().UItoTop({
         		easingType: 'easeOutQuart'
         	});
         });
      </script>
      <a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
      <!-- //for-bottom-to-top smooth scrolling -->
      <!-- bootstrap-->
      <script src="js/bootstrap.js"></script>
      <!--// bootstrap-->
      <!-- Google translate -->
      <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
   </body>
</html>